# Python Fantasy Cricket Game
It  is Python GUI Game where you create a virtual team of real cricket players and score points depending  on how your chosen players perform in real life matches.

## Requirements
# Install Some Necessary Packages and Softwares

 1) Install PyQT5 Package
 * Open Command Prompt by using Shortcut (Window key+R) and type cmd.
 * Type following command in cmd :-
      * pip install pyqt5
 2) Install sqlite3 Package
 * Open Command Prompt by using Shortcut (Window key+R) and type cmd.
 * Type following command in cmd :-
      * pip install db-sqlite3
 3) [Install](https://sqlitestudio.pl/index.rvt?act=download) Sqlite3 Studio

### Run main.py file on CMD.

## Screenshots

![Pic1.png](https://registrationformusingjavascript.000webhostapp.com/Python%20GUI%20Cricket%20Game/Pic%201.png)

![Pic2.png](https://registrationformusingjavascript.000webhostapp.com/Python%20GUI%20Cricket%20Game/Pic%202.png)

![Pic3.png](https://registrationformusingjavascript.000webhostapp.com/Python%20GUI%20Cricket%20Game/Pic%203.png)
